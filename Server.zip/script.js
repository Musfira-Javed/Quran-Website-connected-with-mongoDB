// --- 1. GLOBAL PAGE NAVIGATION ---
function showPage(pageId) {
    document.getElementById('home-page').classList.add('hidden');
    document.getElementById('signup-page').classList.add('hidden');
    document.getElementById('login-page').classList.add('hidden');
    document.getElementById('dashboard-page').classList.add('hidden');

    document.getElementById(pageId).classList.remove('hidden');
}

// --- 2. AUTH HANDLERS (NODE.JS CONNECTED) ---

// Signup Function
async function handleSignup(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries()); // Data ko JSON banaya

    try {
        const response = await fetch('http://localhost:3000/signup', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data) 
        });
        const result = await response.json();

        alert(result.message);
        if (result.status === "success") {
            showPage('login-page');
        }
    } catch (error) {
        console.error('Error:', error);
        alert("Signup Failed. Make sure server is running (node server.js)");
    }
}

// Login Function
async function handleLogin(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch('http://localhost:3000/login', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data) 
        });
        const result = await response.json();

        if (result.status === "success") {
            alert(result.message);
            
            // --- IMPORTANT: User ID save karna ---
            localStorage.setItem('currentUserId', result.user_id);

            // Database se aya hua Tasbeeh Count set karein
            tasbeehCount = parseInt(result.tasbeeh_count);
            document.getElementById('tasbeeh-count').innerText = tasbeehCount;

            showPage('dashboard-page');
            openDashboardSection('dashboard-home');
            fetchPrayerTimes(); // Fetch Prayer times when logging in
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert("Login Failed. Make sure server is running.");
    }
}

function logout() {
    if (confirm("Are you sure you want to sign out?")) {
        // Pehle data save karein
        saveToDB().then(() => {
            // Phir ID clear karein aur reload karein
            localStorage.removeItem('currentUserId');
            window.location.reload(); 
        });
    }
}

// --- 3. DASHBOARD INTERNAL NAVIGATION ---
function openDashboardSection(sectionId) {
    // List of all sections to hide
    const sections = ['dashboard-home', 'about-section', 'contact-section', 'tasbeeh-page'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if(el) el.classList.add('hidden');
    });

    // Hide PDF Viewer
    const viewer = document.getElementById('pdf-viewer');
    viewer.classList.add('hidden');
    viewer.src = "";

    // Show Target Section
    const target = document.getElementById(sectionId);
    if(target) target.classList.remove('hidden');
}

function openViewer(type) {
    openDashboardSection('none'); // Hides home/about/contact/tasbeeh
    const viewer = document.getElementById('pdf-viewer');
    viewer.classList.remove('hidden');

    if (type === 'quran') {
        viewer.src = "pdfs/quran.pdf";
    } else if (type === 'azkar') {
        viewer.src = "pdfs/azkar.pdf";
    }
}

// --- 4. YOUTUBE VIDEO LOGIC ---
document.addEventListener("DOMContentLoaded", function() {
    const videoCards = document.querySelectorAll(".video-card");
    videoCards.forEach(card => {
        card.addEventListener("click", function() {
            const videoId = this.getAttribute("data-video-id");
            const iframe = document.createElement("iframe");
            iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
            iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
            iframe.allowFullscreen = true;
            iframe.style.width = "100%";
            iframe.style.height = "100%";
            iframe.style.border = "none";
            this.innerHTML = "";
            this.appendChild(iframe);
        });
    });
});

// --- 5. NEW FEATURES LOGIC ---

// DARK MODE TOGGLE
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

// --- Q&A HANDLING (NODE.JS CONNECTED) ---
async function handleQuestion(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    // Button disable UI feedback
    const btn = e.target.querySelector('button');
    const originalText = btn.innerHTML;
    btn.innerText = "Sending...";
    btn.disabled = true;

    try {
        const response = await fetch('http://localhost:3000/ask_question', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data) 
        });
        const result = await response.json();
        
        alert(result.message);
        if(result.status === 'success') e.target.reset();
    } catch (error) {
        console.error('Error:', error);
        alert("Could not send question.");
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// --- DIGITAL TASBEEH LOGIC (AUTO SAVE) ---
let tasbeehCount = 0;
let saveTimeout; // Timer ke liye variable

function countTasbeeh() {
    tasbeehCount++;
    document.getElementById('tasbeeh-count').innerText = tasbeehCount;
    
    // LED Effect
    const led = document.querySelector('.led-indicator');
    if(led) {
        led.style.background = '#00ff00';
        led.style.boxShadow = '0 0 10px #00ff00';
        setTimeout(() => { 
            led.style.background = 'red'; 
            led.style.boxShadow = '0 0 5px red';
        }, 100);
    }

    // Debouncing: Jab user click rok dega tab save karenge
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(saveToDB, 1000); 
}

function resetTasbeeh() {
    if(confirm("Reset Counter?")) {
        tasbeehCount = 0;
        document.getElementById('tasbeeh-count').innerText = 0;
        saveToDB(); // Reset hote hi save karein
    }
}

// --- SAVE TASBEEH (UPDATED WITH USER ID) ---
async function saveToDB() {
    const userId = localStorage.getItem('currentUserId');
    
    // Agar user login nahi hai to save mat karo
    if (!userId) return; 

    const data = { 
        user_id: userId, 
        count: tasbeehCount 
    };

    try {
        await fetch('http://localhost:3000/update_tasbeeh', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data) 
        });
        console.log("Tasbeeh Saved to DB");
    } catch (error) {
        console.error("Save Error", error);
    }
}

// --- 6. PRAYER TIMES (Auto-Faisalabad via API) ---
async function fetchPrayerTimes() {
    try {
        // Fetching for Faisalabad, Pakistan
        const response = await fetch('https://api.aladhan.com/v1/timingsByCity?city=Faisalabad&country=Pakistan&method=1');
        const data = await response.json();
        
        if(data.code === 200) {
            const t = data.data.timings;
            // Updating HTML elements
            if(document.getElementById('fajr-time')) document.getElementById('fajr-time').innerText = formatTime(t.Fajr);
            if(document.getElementById('dhuhr-time')) document.getElementById('dhuhr-time').innerText = formatTime(t.Dhuhr);
            if(document.getElementById('asr-time')) document.getElementById('asr-time').innerText = formatTime(t.Asr);
            if(document.getElementById('maghrib-time')) document.getElementById('maghrib-time').innerText = formatTime(t.Maghrib);
            if(document.getElementById('isha-time')) document.getElementById('isha-time').innerText = formatTime(t.Isha);
        }
    } catch (error) {
        console.error("Prayer time error:", error);
    }
}

// Helper: 24h to 12h format converter
function formatTime(timeStr) {
    let [hours, minutes] = timeStr.split(':');
    hours = parseInt(hours);
    let ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    return `${hours}:${minutes} ${ampm}`;
}

// --- 7. CONTACT FORM HANDLING (NEW ADDITION) ---
async function handleContact(e) {
    e.preventDefault(); // Page reload hone se rokta hai
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries()); // Data JSON banata hai

    // Button UI Change
    const btn = e.target.querySelector('button');
    const originalText = btn.innerHTML;
    btn.innerText = "Sending...";
    btn.disabled = true;

    try {
        const response = await fetch('http://localhost:3000/contact', { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data) 
        });
        const result = await response.json();
        
        alert(result.message);
        if(result.status === 'success') e.target.reset(); // Form khali kar do
    } catch (error) {
        console.error('Error:', error);
        alert("Could not send message. Server check karein.");
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}