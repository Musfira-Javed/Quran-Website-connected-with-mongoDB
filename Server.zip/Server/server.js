const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

// --- SETTING ---
app.use(cors()); 
app.use(bodyParser.json());

// --- DATABASE CONNECTION ---
mongoose.connect('mongodb://127.0.0.1:27017/quranclub')
.then(() => console.log("✅ MongoDB Connected!"))
.catch(err => console.log("❌ Error:", err));

// --- DATABASE MODELS (TABLES) ---

// 1. User Model
const UserSchema = new mongoose.Schema({
    full_name: String,
    email: { type: String, unique: true, required: true },
    password: String,
    tasbeeh_count: { type: Number, default: 0 } 
});
const User = mongoose.model('User', UserSchema);

// 2. Question Model
const QuestionSchema = new mongoose.Schema({
    user_name: String,
    question: String
});
const Question = mongoose.model('Question', QuestionSchema);

// 3. Contact Model (Ye Naya Hai)
const ContactSchema = new mongoose.Schema({
    name: String,
    email: String,
    message: String,
    date: { type: Date, default: Date.now }
});
const Contact = mongoose.model('Contact', ContactSchema);


// --- API ROUTES ---

// 1. Signup Route
app.post('/signup', async (req, res) => {
    const { full_name, email, password } = req.body;
    try {
        const newUser = new User({ full_name, email, password });
        await newUser.save();
        res.json({ status: "success", message: "Account Created!" });
    } catch (error) {
        res.json({ status: "error", message: "Email already exists or Error." });
    }
});

// 2. Login Route
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email, password });
        if (user) {
            res.json({ 
                status: "success", 
                message: "Welcome!", 
                user_id: user._id, 
                tasbeeh_count: user.tasbeeh_count 
            });
        } else {
            res.json({ status: "error", message: "Wrong Email or Password" });
        }
    } catch (error) {
        res.json({ status: "error", message: "Server Error" });
    }
});

// 3. Update Tasbeeh Route
app.post('/update_tasbeeh', async (req, res) => {
    const { user_id, count } = req.body;
    if(user_id) {
        await User.findByIdAndUpdate(user_id, { tasbeeh_count: count });
        res.json({ status: "success" });
    }
});

// 4. Ask Question Route
app.post('/ask_question', async (req, res) => {
    const { user_name, question } = req.body;
    const newQ = new Question({ user_name, question });
    await newQ.save();
    res.json({ status: "success", message: "Question Sent!" });
});

// 5. Contact Form Route (Ye Missing Tha, Maine Add Kar Diya Hai)
app.post('/contact', async (req, res) => {
    const { name, email, message } = req.body;
    try {
        const newContact = new Contact({ name, email, message });
        await newContact.save();
        res.json({ status: "success", message: "Message sent successfully!" });
    } catch (error) {
        res.json({ status: "error", message: "Failed to send message." });
    }
});

// --- SERVER START ---
app.listen(3000, () => {
    console.log("🚀 Server running at http://localhost:3000");
});